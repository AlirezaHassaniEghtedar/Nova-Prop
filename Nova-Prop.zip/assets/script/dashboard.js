// const dashboardMenuIcon = document.querySelector('.sidebar-toggle-btn img');

// dashboardMenuIcon.addEventListener('click' , handleDashboardMenuIconClick)

// function handleDashboardMenuIconClick(e) {

// }